#include "Header.cpp"

int findLeader(Vote* voteArray[],int n) {
	// To be implemented.
        // returns index in the array of any object representing the leader, if a leader exists for the array.
	// returns -1 otherwise.
	return -2;
};
 
int findMaxSubmatrixSum(Matrix mat) {
	

    /*
     
     
     * Given a 
     * This function takes a matrix object in which
     * the entries in each row AND each colum are decreasing.
     * It assumes that at least one entry in the matrix (in particular
     * the top left entry) is non-negative.
     * It returns the 
     * sum of the entries in the maximum weight submatrix.
     * 
     * For example, if given the matrix

	15      12      4
	13      -1      -3
	8       -9      -10

     * your answer must be 40. (Do you see why?)
     * 
     * 
     
     
     */

	// To be implemented.
	return -1;
}
