#include "BinaryTree.cpp"



bool BinaryTree::DFS_visit(int node) {
	 /*
                Recursive call to execute DFS.
                During this execution, the pre-visit and post-visit numbers must be computed and stored
                in the pre and post arraygs.
                
                For each node i, you must store the height of the subtree rooted at i in height[i].
        
        */

	return false;
}

bool isAncestor(BinaryTree tree, int anc, int desc) {
	/*
		This function must return true if the node anc is an ancestor of node desc in tree. 
		You may assume that anc and desc are valid nodes in tree.
	*/
	
	return false;
}
	
int LCA(BinaryTree tree, int n1, int n2) {
	/*
		This function must take two valid nodes n1 and n2 in tree and return the lowest common ancestor. 
		The lowest common ancestor of n1 and n2 is a node in the tree which is a ancestor of both n1 and n2, 
		but neither of its children and common ancestors to both n1 and n2.
	*/
	return -1;
}
int subTreeSize(BinaryTree tree, int node){
		/*
			Must return the number of nodes in the subtree rooted at node.
			The function must run in $O(1)$ time.
		*/
		return -1;
}
	
bool isBalanced(BinaryTree tree, int node) {
	/*
		Must return true iff the subtree (in tree) that is rooted at node is height balanced.
		A (sub)tree is height balanced if, for every node in the (sub)tree, the heights of its two children 
		differ by at most 1.
		
		
	*/
	return false;
}
	
int diameter(BinaryTree tree) {
	return -1;
}
