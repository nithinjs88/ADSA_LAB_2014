#include "BinaryTree.cpp"
		
extern bool isAncestor(BinaryTree tree, int anc, int desc);

extern int LCA(BinaryTree tree, int n1, int n2);

extern int subTreeSize(BinaryTree tree, int node);

extern bool isBalanced(BinaryTree tree, int node);

extern int diameter(BinaryTree tree);
	
int main(int argc, char** argv) {
	
	BinaryTree tree;
	
	 if (argc != 3) {
                std::cout << "Invalid number of arguments.\nUsage: " << argv[0] << " <inputFile> <outFile>\n";
                return 1;
        }

	tree.readFile(argv[1]);
	tree.DFS();
	tree.gvout(argv[2]);
	
	cout << "LCA of 5 and 7 is " << LCA(tree,5,7) << endl;
	cout << "LCA of 6 and 7 is " << LCA(tree,6,7) << endl;
	
	cout << "Balance = " << isBalanced(tree, 1) << endl;
	
	cout << "Size of tree = " << subTreeSize(tree,1) << endl;
	cout <<"Diameter of tree =" << diameter(tree) <<endl;
	return 0;
}
